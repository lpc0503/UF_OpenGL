# Book - Vertex chameleon study

From: https://sketchfab.com/3d-models/book-vertex-chameleon-study-51b0b3bdcd844a9e951a9ede6f192da8

# Author: Oleaf

https://sketchfab.com/homkahom0

# License: CC-BY-NC

http://creativecommons.org/licenses/by-nc/4.0/
