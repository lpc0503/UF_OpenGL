# Chair

https://sketchfab.com/3d-models/chair-aa2acddb218646a59ece132bf95aa558

# By haytonm

https://sketchfab.com/haytonm

# License: CC-BY 4.0

http://creativecommons.org/licenses/by/4.0/